<?php
return array (
  'time' => 1624339049,
  'data' => 
  array (
    0 => 
    array (
      'component' => 'hotList',
      'text' => '热点榜',
      'typeName' => 'realtime',
      'content' => 
      array (
        0 => 
        array (
          'index' => 0,
          'word' => '广东昨日新增2例本土确诊病例',
          'query' => '广东昨日新增2例本土确诊病例',
          'show' => 
          array (
          ),
          'desc' => '6月21日0-24时，广东新增2例本土确诊病例，深圳报告1例，东莞报告1例。',
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1//2818645318b88b0f1e6d5c6a073dd43d',
          'url' => 'https://www.baidu.com/s?wd=%E5%B9%BF%E4%B8%9C%E6%98%A8%E6%97%A5%E6%96%B0%E5%A2%9E2%E4%BE%8B%E6%9C%AC%E5%9C%9F%E7%A1%AE%E8%AF%8A%E7%97%85%E4%BE%8B&rsv_dl=fyb_homepage_news',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%B9%BF%E4%B8%9C%E6%98%A8%E6%97%A5%E6%96%B0%E5%A2%9E2%E4%BE%8B%E6%9C%AC%E5%9C%9F%E7%A1%AE%E8%AF%8A%E7%97%85%E4%BE%8B',
          'hotScore' => '4942516',
          'hotChange' => 'same',
          'hotTag' => '0',
        ),
        1 => 
        array (
          'index' => 1,
          'word' => '中国驻美大使崔天凯发表辞别信',
          'query' => '中国驻美大使崔天凯发表辞别信',
          'show' => 
          array (
          ),
          'desc' => '中国驻美国大使馆网站6月22日消息，中国驻美国大使崔天凯发表致全美侨胞的辞别信：将于近日离任回国，在美侨胞肩负更重大责任和使命。',
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1//fb0d4f931b7b72744fb1a4998526f49b',
          'url' => 'https://www.baidu.com/s?wd=%E4%B8%AD%E5%9B%BD%E9%A9%BB%E7%BE%8E%E5%A4%A7%E4%BD%BF%E5%B4%94%E5%A4%A9%E5%87%AF%E5%8F%91%E8%A1%A8%E8%BE%9E%E5%88%AB%E4%BF%A1&rsv_dl=fyb_homepage_news',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E4%B8%AD%E5%9B%BD%E9%A9%BB%E7%BE%8E%E5%A4%A7%E4%BD%BF%E5%B4%94%E5%A4%A9%E5%87%AF%E5%8F%91%E8%A1%A8%E8%BE%9E%E5%88%AB%E4%BF%A1',
          'hotScore' => '4829852',
          'hotChange' => 'same',
          'hotTag' => '3',
        ),
        2 => 
        array (
          'index' => 2,
          'word' => '东莞3病例曾同时在麦当劳用餐',
          'query' => '东莞3病例曾同时在麦当劳用餐',
          'show' => 
          array (
          ),
          'desc' => '22日，东莞新增1例确诊病例。从流调报告得知，东莞报告的3名确诊病例——李某婷，大学生贾某某和井某， 6月12日都曾在麻涌星河城商场麦当劳用餐。',
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1//2818645318b88b0f1e6d5c6a073dd43d',
          'url' => 'https://www.baidu.com/s?wd=%E4%B8%9C%E8%8E%9E3%E7%97%85%E4%BE%8B%E6%9B%BE%E5%90%8C%E6%97%B6%E5%9C%A8%E9%BA%A6%E5%BD%93%E5%8A%B3%E7%94%A8%E9%A4%90&rsv_dl=fyb_homepage_news',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E4%B8%9C%E8%8E%9E3%E7%97%85%E4%BE%8B%E6%9B%BE%E5%90%8C%E6%97%B6%E5%9C%A8%E9%BA%A6%E5%BD%93%E5%8A%B3%E7%94%A8%E9%A4%90',
          'hotScore' => '4738301',
          'hotChange' => 'same',
          'hotTag' => '1',
        ),
        3 => 
        array (
          'index' => 3,
          'word' => '美商务部撤销对TikTok和WeChat禁令',
          'query' => '美商务部撤销对TikTok和WeChat禁令',
          'show' => 
          array (
          ),
          'desc' => '美国商务部当地时间21日表示，正在撤销对社交媒体应用TikTok和WeChat 的禁令。',
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1//e80da366a9a5b9958c2142de5feb9ed9',
          'url' => 'https://www.baidu.com/s?wd=%E7%BE%8E%E5%95%86%E5%8A%A1%E9%83%A8%E6%92%A4%E9%94%80%E5%AF%B9TikTok%E5%92%8CWeChat%E7%A6%81%E4%BB%A4&rsv_dl=fyb_homepage_news',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E7%BE%8E%E5%95%86%E5%8A%A1%E9%83%A8%E6%92%A4%E9%94%80%E5%AF%B9TikTok%E5%92%8CWeChat%E7%A6%81%E4%BB%A4',
          'hotScore' => '4649108',
          'hotChange' => 'same',
          'hotTag' => '0',
        ),
        4 => 
        array (
          'index' => 4,
          'word' => '东京奥运入场观众上限为1万人',
          'query' => '东京奥运入场观众上限为1万人',
          'show' => 
          array (
          ),
          'desc' => '21日，东京奥运会和残奥会组织委员会、东京都、日本政府、国际奥委会、国际残奥委会的代表举行磋商，正式决定东京奥运会观众人数上限1万人。',
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1//d20de58d4a4a5d66b48c5c6b3d79d6b5',
          'url' => 'https://www.baidu.com/s?wd=%E4%B8%9C%E4%BA%AC%E5%A5%A5%E8%BF%90%E5%85%A5%E5%9C%BA%E8%A7%82%E4%BC%97%E4%B8%8A%E9%99%90%E4%B8%BA1%E4%B8%87%E4%BA%BA&rsv_dl=fyb_homepage_news',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E4%B8%9C%E4%BA%AC%E5%A5%A5%E8%BF%90%E5%85%A5%E5%9C%BA%E8%A7%82%E4%BC%97%E4%B8%8A%E9%99%90%E4%B8%BA1%E4%B8%87%E4%BA%BA',
          'hotScore' => '4585821',
          'hotChange' => 'same',
          'hotTag' => '1',
        ),
        5 => 
        array (
          'index' => 5,
          'word' => '北京建党百年大型文艺演出将放烟花',
          'query' => '北京建党百年大型文艺演出将放烟花',
          'show' => 
          array (
          ),
          'desc' => '北京市人民政府：在2021年6月下旬举办的庆祝中国共产党成立100周年大型文艺演出活动期间，北京将在指定地点燃放烟花。',
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1//add2dbd5677a631f5c7c70248022bb36',
          'url' => 'https://www.baidu.com/s?wd=%E5%8C%97%E4%BA%AC%E5%BB%BA%E5%85%9A%E7%99%BE%E5%B9%B4%E5%A4%A7%E5%9E%8B%E6%96%87%E8%89%BA%E6%BC%94%E5%87%BA%E5%B0%86%E6%94%BE%E7%83%9F%E8%8A%B1&rsv_dl=fyb_homepage_news',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%8C%97%E4%BA%AC%E5%BB%BA%E5%85%9A%E7%99%BE%E5%B9%B4%E5%A4%A7%E5%9E%8B%E6%96%87%E8%89%BA%E6%BC%94%E5%87%BA%E5%B0%86%E6%94%BE%E7%83%9F%E8%8A%B1',
          'hotScore' => '4497289',
          'hotChange' => 'same',
          'hotTag' => '0',
        ),
        6 => 
        array (
          'index' => 6,
          'word' => '美公布5500万剂疫苗全球分配计划',
          'query' => '美公布5500万剂疫苗全球分配计划',
          'show' => 
          array (
          ),
          'desc' => '21日，美国白宫公布了5500万剂新冠疫苗全球分配计划。美国总统拜登5月曾表示，美国将在6月底前向全球分享8000万剂新冠疫苗。',
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1//24bd958c8cc73a9a6d9cd720de135959',
          'url' => 'https://www.baidu.com/s?wd=%E7%BE%8E%E5%85%AC%E5%B8%835500%E4%B8%87%E5%89%82%E7%96%AB%E8%8B%97%E5%85%A8%E7%90%83%E5%88%86%E9%85%8D%E8%AE%A1%E5%88%92&rsv_dl=fyb_homepage_news',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E7%BE%8E%E5%85%AC%E5%B8%835500%E4%B8%87%E5%89%82%E7%96%AB%E8%8B%97%E5%85%A8%E7%90%83%E5%88%86%E9%85%8D%E8%AE%A1%E5%88%92',
          'hotScore' => '4285829',
          'hotChange' => 'same',
          'hotTag' => '0',
        ),
        7 => 
        array (
          'index' => 7,
          'word' => '河北张家口发生3.9级地震',
          'query' => '河北张家口发生3.9级地震',
          'show' => 
          array (
          ),
          'desc' => '中国地震台网正式测定：06月22日11时14分在河北张家口市张北县（北纬41.17度，东经114.41度）发生3.9级地震，震源深度10千米。',
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1//1effb36f9f17a06afe29176b908a8d64',
          'url' => 'https://www.baidu.com/s?wd=%E6%B2%B3%E5%8C%97%E5%BC%A0%E5%AE%B6%E5%8F%A3%E5%8F%91%E7%94%9F3.9%E7%BA%A7%E5%9C%B0%E9%9C%87&rsv_dl=fyb_homepage_news',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%B2%B3%E5%8C%97%E5%BC%A0%E5%AE%B6%E5%8F%A3%E5%8F%91%E7%94%9F3.9%E7%BA%A7%E5%9C%B0%E9%9C%87',
          'hotScore' => '4105865',
          'hotChange' => 'same',
          'hotTag' => '3',
        ),
        8 => 
        array (
          'index' => 8,
          'word' => '重庆发现4.23亿年前袖珍边城鱼',
          'query' => '重庆发现4.23亿年前袖珍边城鱼',
          'show' => 
          array (
          ),
          'desc' => '重庆市秀山县发现距今约4.23亿年前、保存完整的新属种有颌鱼类——袖珍边城鱼。',
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1//5a199158c18f7e26036b82d0f9e469e0',
          'url' => 'https://www.baidu.com/s?wd=%E9%87%8D%E5%BA%86%E5%8F%91%E7%8E%B04.23%E4%BA%BF%E5%B9%B4%E5%89%8D%E8%A2%96%E7%8F%8D%E8%BE%B9%E5%9F%8E%E9%B1%BC&rsv_dl=fyb_homepage_news',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E9%87%8D%E5%BA%86%E5%8F%91%E7%8E%B04.23%E4%BA%BF%E5%B9%B4%E5%89%8D%E8%A2%96%E7%8F%8D%E8%BE%B9%E5%9F%8E%E9%B1%BC',
          'hotScore' => '4065295',
          'hotChange' => 'same',
          'hotTag' => '0',
        ),
        9 => 
        array (
          'index' => 9,
          'word' => '歌手徐真真全身二级深度烧伤',
          'query' => '歌手徐真真全身二级深度烧伤',
          'show' => 
          array (
          ),
          'desc' => '21日，嘻哈歌手徐真真在社交媒体上发文，透露其上周六因点香薰蜡烛没有熄灭就睡觉，引发火灾，致全身40%二级深度烧伤。目前已度过危险期，仍在医院治疗。',
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1//5d000374fa8e70d7b49eb77a14b8711c',
          'url' => 'https://www.baidu.com/s?wd=%E6%AD%8C%E6%89%8B%E5%BE%90%E7%9C%9F%E7%9C%9F%E5%85%A8%E8%BA%AB%E4%BA%8C%E7%BA%A7%E6%B7%B1%E5%BA%A6%E7%83%A7%E4%BC%A4&rsv_dl=fyb_homepage_news',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%AD%8C%E6%89%8B%E5%BE%90%E7%9C%9F%E7%9C%9F%E5%85%A8%E8%BA%AB%E4%BA%8C%E7%BA%A7%E6%B7%B1%E5%BA%A6%E7%83%A7%E4%BC%A4',
          'hotScore' => '3973279',
          'hotChange' => 'same',
          'hotTag' => '3',
        ),
      ),
      'more' => 1,
      'moreUrl' => 'https://top.baidu.com/board?tab=realtime',
    ),
    1 => 
    array (
      'component' => 'textImgListVerticalSmall',
      'text' => '小说榜',
      'typeName' => 'novel',
      'content' => 
      array (
        0 => 
        array (
          'index' => 0,
          'word' => '仙帝归来',
          'query' => '仙帝归来 小说',
          'show' => 
          array (
            0 => '妖火 | 玄幻',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/dfbf00aed96ed697a41573192ffe66cb',
          'url' => 'https://www.baidu.com/s?wd=%E4%BB%99%E5%B8%9D%E5%BD%92%E6%9D%A5+%E5%B0%8F%E8%AF%B4&rsv_dl=fyb_homepage_novel',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E4%BB%99%E5%B8%9D%E5%BD%92%E6%9D%A5',
          'hotScore' => '21631',
          'hotChange' => 'same',
        ),
        1 => 
        array (
          'index' => 1,
          'word' => '重生之都市仙尊',
          'query' => '重生之都市仙尊 小说',
          'show' => 
          array (
            0 => '沐仹 | 都市',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/9c0102d4f429b0e71f65aae21fdb4fca',
          'url' => 'https://www.baidu.com/s?wd=%E9%87%8D%E7%94%9F%E4%B9%8B%E9%83%BD%E5%B8%82%E4%BB%99%E5%B0%8A+%E5%B0%8F%E8%AF%B4&rsv_dl=fyb_homepage_novel',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E9%87%8D%E7%94%9F%E4%B9%8B%E9%83%BD%E5%B8%82%E4%BB%99%E5%B0%8A',
          'hotScore' => '6780',
          'hotChange' => 'up',
        ),
        2 => 
        array (
          'index' => 2,
          'word' => '武神至尊',
          'query' => '武神至尊 小说',
          'show' => 
          array (
            0 => '我吃面包 | 武侠',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/f573f7fea83ca12f163b9be648631fe6',
          'url' => 'https://www.baidu.com/s?wd=%E6%AD%A6%E7%A5%9E%E8%87%B3%E5%B0%8A+%E5%B0%8F%E8%AF%B4&rsv_dl=fyb_homepage_novel',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%AD%A6%E7%A5%9E%E8%87%B3%E5%B0%8A',
          'hotScore' => '6039',
          'hotChange' => 'same',
        ),
        3 => 
        array (
          'index' => 3,
          'word' => '修仙狂徒',
          'query' => '修仙狂徒 小说',
          'show' => 
          array (
            0 => '王小蛮 | 玄幻',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/72138bec530741c13f4aced9860667cd',
          'url' => 'https://www.baidu.com/s?wd=%E4%BF%AE%E4%BB%99%E7%8B%82%E5%BE%92+%E5%B0%8F%E8%AF%B4&rsv_dl=fyb_homepage_novel',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E4%BF%AE%E4%BB%99%E7%8B%82%E5%BE%92',
          'hotScore' => '4492',
          'hotChange' => 'same',
        ),
        4 => 
        array (
          'index' => 4,
          'word' => '百炼成神',
          'query' => '百炼成神 小说',
          'show' => 
          array (
            0 => '恩赐解脱 | 玄幻',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/024d31b7cf4c1156f2dcd14549ffc713',
          'url' => 'https://www.baidu.com/s?wd=%E7%99%BE%E7%82%BC%E6%88%90%E7%A5%9E+%E5%B0%8F%E8%AF%B4&rsv_dl=fyb_homepage_novel',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E7%99%BE%E7%82%BC%E6%88%90%E7%A5%9E',
          'hotScore' => '3408',
          'hotChange' => 'same',
        ),
        5 => 
        array (
          'index' => 5,
          'word' => '绝世邪神',
          'query' => '绝世邪神 小说',
          'show' => 
          array (
            0 => '纯情犀利哥 | 玄幻',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/f9a0d988ba494a19145413e1729f0827',
          'url' => 'https://www.baidu.com/s?wd=%E7%BB%9D%E4%B8%96%E9%82%AA%E7%A5%9E+%E5%B0%8F%E8%AF%B4&rsv_dl=fyb_homepage_novel',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E7%BB%9D%E4%B8%96%E9%82%AA%E7%A5%9E',
          'hotScore' => '2966',
          'hotChange' => 'same',
        ),
        6 => 
        array (
          'index' => 6,
          'word' => '不死战神',
          'query' => '不死战神 小说',
          'show' => 
          array (
            0 => '腹黑的蚂蚁 | 玄幻',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/dd81413cb3fb690f4076978992d27e8d',
          'url' => 'https://www.baidu.com/s?wd=%E4%B8%8D%E6%AD%BB%E6%88%98%E7%A5%9E+%E5%B0%8F%E8%AF%B4&rsv_dl=fyb_homepage_novel',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E4%B8%8D%E6%AD%BB%E6%88%98%E7%A5%9E',
          'hotScore' => '2732',
          'hotChange' => 'same',
        ),
        7 => 
        array (
          'index' => 7,
          'word' => '医妃惊世',
          'query' => '医妃惊世 小说',
          'show' => 
          array (
            0 => '蝴蝶追梦 | 全部',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/e0e3d7190cff66f6647528926618f536',
          'url' => 'https://www.baidu.com/s?wd=%E5%8C%BB%E5%A6%83%E6%83%8A%E4%B8%96+%E5%B0%8F%E8%AF%B4&rsv_dl=fyb_homepage_novel',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%8C%BB%E5%A6%83%E6%83%8A%E4%B8%96',
          'hotScore' => '2524',
          'hotChange' => 'same',
        ),
        8 => 
        array (
          'index' => 8,
          'word' => '我的七个姐姐绝色倾城',
          'query' => '我的七个姐姐绝色倾城 小说',
          'show' => 
          array (
            0 => '苏生奈何 | 纯爱',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/d2dc8a0f66f636bfca4bc28542989bdb',
          'url' => 'https://www.baidu.com/s?wd=%E6%88%91%E7%9A%84%E4%B8%83%E4%B8%AA%E5%A7%90%E5%A7%90%E7%BB%9D%E8%89%B2%E5%80%BE%E5%9F%8E+%E5%B0%8F%E8%AF%B4&rsv_dl=fyb_homepage_novel',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%88%91%E7%9A%84%E4%B8%83%E4%B8%AA%E5%A7%90%E5%A7%90%E7%BB%9D%E8%89%B2%E5%80%BE%E5%9F%8E',
          'hotScore' => '1702',
          'hotChange' => 'same',
        ),
        9 => 
        array (
          'index' => 9,
          'word' => '异世猎芳逍遥',
          'query' => '异世猎芳逍遥 小说',
          'show' => 
          array (
            0 => '青弓半月勾 | 玄幻',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/0b17a8862bca073e636d966abeba4b0c',
          'url' => 'https://www.baidu.com/s?wd=%E5%BC%82%E4%B8%96%E7%8C%8E%E8%8A%B3%E9%80%8D%E9%81%A5+%E5%B0%8F%E8%AF%B4&rsv_dl=fyb_homepage_novel',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%BC%82%E4%B8%96%E7%8C%8E%E8%8A%B3%E9%80%8D%E9%81%A5',
          'hotScore' => '1532',
          'hotChange' => 'same',
        ),
      ),
      'more' => 1,
      'moreUrl' => 'https://top.baidu.com/board?tab=novel',
    ),
    2 => 
    array (
      'component' => 'textImgListVerticalSmall',
      'text' => '电影榜',
      'typeName' => 'movie',
      'content' => 
      array (
        0 => 
        array (
          'index' => 0,
          'word' => '悬崖之上',
          'query' => '悬崖之上 电影',
          'show' => 
          array (
            0 => '中国大陆 | 剧情',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/5035dfa2c7e2f60f7998beed65f6ab6c',
          'url' => 'https://www.baidu.com/s?wd=%E6%82%AC%E5%B4%96%E4%B9%8B%E4%B8%8A+%E7%94%B5%E5%BD%B1&rsv_dl=fyb_homepage_movie',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%82%AC%E5%B4%96%E4%B9%8B%E4%B8%8A',
          'hotScore' => '270545',
          'hotChange' => 'up',
        ),
        1 => 
        array (
          'index' => 1,
          'word' => '当男人恋爱时',
          'query' => '当男人恋爱时 电影',
          'show' => 
          array (
            0 => '台湾 | 爱情',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/10f123afd916c493fefaf55ff7d208aa',
          'url' => 'https://www.baidu.com/s?wd=%E5%BD%93%E7%94%B7%E4%BA%BA%E6%81%8B%E7%88%B1%E6%97%B6+%E7%94%B5%E5%BD%B1&rsv_dl=fyb_homepage_movie',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%BD%93%E7%94%B7%E4%BA%BA%E6%81%8B%E7%88%B1%E6%97%B6',
          'hotScore' => '33598',
          'hotChange' => 'up',
        ),
        2 => 
        array (
          'index' => 2,
          'word' => '你好李焕英',
          'query' => '你好李焕英 电影',
          'show' => 
          array (
            0 => '中国大陆 | 剧情',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/0996b964627f4e5ed15df42c8b9caed9',
          'url' => 'https://www.baidu.com/s?wd=%E4%BD%A0%E5%A5%BD%E6%9D%8E%E7%84%95%E8%8B%B1+%E7%94%B5%E5%BD%B1&rsv_dl=fyb_homepage_movie',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E4%BD%A0%E5%A5%BD%E6%9D%8E%E7%84%95%E8%8B%B1',
          'hotScore' => '27511',
          'hotChange' => 'up',
        ),
        3 => 
        array (
          'index' => 3,
          'word' => '阳光姐妹淘',
          'query' => '阳光姐妹淘 电影',
          'show' => 
          array (
            0 => '中国大陆 | 剧情',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/37c1f00163fadbf64f701299b822f24e',
          'url' => 'https://www.baidu.com/s?wd=%E9%98%B3%E5%85%89%E5%A7%90%E5%A6%B9%E6%B7%98+%E7%94%B5%E5%BD%B1&rsv_dl=fyb_homepage_movie',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E9%98%B3%E5%85%89%E5%A7%90%E5%A6%B9%E6%B7%98',
          'hotScore' => '27363',
          'hotChange' => 'same',
        ),
        4 => 
        array (
          'index' => 4,
          'word' => '速度与激情9',
          'query' => '速度与激情9 电影',
          'show' => 
          array (
            0 => '欧美 | 犯罪',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/00f1c5dc0dc0bc5371d89985035328bc',
          'url' => 'https://www.baidu.com/s?wd=%E9%80%9F%E5%BA%A6%E4%B8%8E%E6%BF%80%E6%83%859+%E7%94%B5%E5%BD%B1&rsv_dl=fyb_homepage_movie',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E9%80%9F%E5%BA%A6%E4%B8%8E%E6%BF%80%E6%83%859',
          'hotScore' => '24148',
          'hotChange' => 'up',
        ),
        5 => 
        array (
          'index' => 5,
          'word' => '哥斯拉大战金刚',
          'query' => '哥斯拉大战金刚 电影',
          'show' => 
          array (
            0 => '欧美 | 科幻',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/7eed27649548d0c36fcea73a9d85b90d',
          'url' => 'https://www.baidu.com/s?wd=%E5%93%A5%E6%96%AF%E6%8B%89%E5%A4%A7%E6%88%98%E9%87%91%E5%88%9A+%E7%94%B5%E5%BD%B1&rsv_dl=fyb_homepage_movie',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%93%A5%E6%96%AF%E6%8B%89%E5%A4%A7%E6%88%98%E9%87%91%E5%88%9A',
          'hotScore' => '22637',
          'hotChange' => 'up',
        ),
        6 => 
        array (
          'index' => 6,
          'word' => '追虎擒龙',
          'query' => '追虎擒龙 电影',
          'show' => 
          array (
            0 => '中国大陆 | 剧情',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/57db65dc69be88a4ba31a778bd98fe20',
          'url' => 'https://www.baidu.com/s?wd=%E8%BF%BD%E8%99%8E%E6%93%92%E9%BE%99+%E7%94%B5%E5%BD%B1&rsv_dl=fyb_homepage_movie',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E8%BF%BD%E8%99%8E%E6%93%92%E9%BE%99',
          'hotScore' => '22225',
          'hotChange' => 'same',
        ),
        7 => 
        array (
          'index' => 7,
          'word' => '父亲',
          'query' => '父亲 电影',
          'show' => 
          array (
            0 => '中国大陆 | 剧情',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/f34ecd3f6b2eb32b5b6f7c7f96db181e',
          'url' => 'https://www.baidu.com/s?wd=%E7%88%B6%E4%BA%B2+%E7%94%B5%E5%BD%B1&rsv_dl=fyb_homepage_movie',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E7%88%B6%E4%BA%B2',
          'hotScore' => '21407',
          'hotChange' => 'up',
        ),
        8 => 
        array (
          'index' => 8,
          'word' => '流浪地球',
          'query' => '流浪地球 电影',
          'show' => 
          array (
            0 => '中国大陆 | 科幻',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/d30af1c75f1d0ef09171c17642cb3a22',
          'url' => 'https://www.baidu.com/s?wd=%E6%B5%81%E6%B5%AA%E5%9C%B0%E7%90%83+%E7%94%B5%E5%BD%B1&rsv_dl=fyb_homepage_movie',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%B5%81%E6%B5%AA%E5%9C%B0%E7%90%83',
          'hotScore' => '13940',
          'hotChange' => 'up',
        ),
        9 => 
        array (
          'index' => 9,
          'word' => '我的姐姐',
          'query' => '我的姐姐 电影',
          'show' => 
          array (
            0 => '中国大陆 | 剧情',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/2262597e6954a9402e9cdda16ef65631',
          'url' => 'https://www.baidu.com/s?wd=%E6%88%91%E7%9A%84%E5%A7%90%E5%A7%90+%E7%94%B5%E5%BD%B1&rsv_dl=fyb_homepage_movie',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%88%91%E7%9A%84%E5%A7%90%E5%A7%90',
          'hotScore' => '13450',
          'hotChange' => 'up',
        ),
      ),
      'more' => 1,
      'moreUrl' => 'https://top.baidu.com/board?tab=movie',
    ),
    3 => 
    array (
      'component' => 'textImgListVerticalSmall',
      'text' => '电视剧榜',
      'typeName' => 'teleplay',
      'content' => 
      array (
        0 => 
        array (
          'index' => 0,
          'word' => '变成你的那一天',
          'query' => '变成你的那一天 电视剧',
          'show' => 
          array (
            0 => '中国大陆 | 剧情',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/adee418333eadef8ed9ef00acfe54343',
          'url' => 'https://www.baidu.com/s?wd=%E5%8F%98%E6%88%90%E4%BD%A0%E7%9A%84%E9%82%A3%E4%B8%80%E5%A4%A9+%E7%94%B5%E8%A7%86%E5%89%A7&rsv_dl=fyb_homepage_teleplay',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%8F%98%E6%88%90%E4%BD%A0%E7%9A%84%E9%82%A3%E4%B8%80%E5%A4%A9',
          'hotScore' => '359070',
          'hotChange' => 'up',
        ),
        1 => 
        array (
          'index' => 1,
          'word' => '叛逆者',
          'query' => '叛逆者 电视剧',
          'show' => 
          array (
            0 => '中国大陆 | 悬疑',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/092a3bed10355d0e4986b549cb7f23a5',
          'url' => 'https://www.baidu.com/s?wd=%E5%8F%9B%E9%80%86%E8%80%85+%E7%94%B5%E8%A7%86%E5%89%A7&rsv_dl=fyb_homepage_teleplay',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%8F%9B%E9%80%86%E8%80%85',
          'hotScore' => '319209',
          'hotChange' => 'same',
        ),
        2 => 
        array (
          'index' => 2,
          'word' => '觉醒年代',
          'query' => '觉醒年代 电视剧',
          'show' => 
          array (
            0 => '中国大陆 | 剧情',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/0db5ebfccee60567fb71caefe704e1e1',
          'url' => 'https://www.baidu.com/s?wd=%E8%A7%89%E9%86%92%E5%B9%B4%E4%BB%A3+%E7%94%B5%E8%A7%86%E5%89%A7&rsv_dl=fyb_homepage_teleplay',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E8%A7%89%E9%86%92%E5%B9%B4%E4%BB%A3',
          'hotScore' => '196292',
          'hotChange' => 'same',
        ),
        3 => 
        array (
          'index' => 3,
          'word' => '爱上特种兵',
          'query' => '爱上特种兵 电视剧',
          'show' => 
          array (
            0 => '中国大陆 | 剧情',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/303d406c5a9ec00161fd834d990297e2',
          'url' => 'https://www.baidu.com/s?wd=%E7%88%B1%E4%B8%8A%E7%89%B9%E7%A7%8D%E5%85%B5+%E7%94%B5%E8%A7%86%E5%89%A7&rsv_dl=fyb_homepage_teleplay',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E7%88%B1%E4%B8%8A%E7%89%B9%E7%A7%8D%E5%85%B5',
          'hotScore' => '137178',
          'hotChange' => 'same',
        ),
        4 => 
        array (
          'index' => 4,
          'word' => '山河令',
          'query' => '山河令 电视剧',
          'show' => 
          array (
            0 => '中国大陆 | 剧情',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/f67217f90b07b57577c7978caafc5321',
          'url' => 'https://www.baidu.com/s?wd=%E5%B1%B1%E6%B2%B3%E4%BB%A4+%E7%94%B5%E8%A7%86%E5%89%A7&rsv_dl=fyb_homepage_teleplay',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%B1%B1%E6%B2%B3%E4%BB%A4',
          'hotScore' => '52456',
          'hotChange' => 'up',
        ),
        5 => 
        array (
          'index' => 5,
          'word' => '花好月又圆',
          'query' => '花好月又圆 电视剧',
          'show' => 
          array (
            0 => '中国大陆 | 古装',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/ed31a02271b7e4c9e647bdde3e5ae071',
          'url' => 'https://www.baidu.com/s?wd=%E8%8A%B1%E5%A5%BD%E6%9C%88%E5%8F%88%E5%9C%86+%E7%94%B5%E8%A7%86%E5%89%A7&rsv_dl=fyb_homepage_teleplay',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E8%8A%B1%E5%A5%BD%E6%9C%88%E5%8F%88%E5%9C%86',
          'hotScore' => '37811',
          'hotChange' => 'down',
        ),
        6 => 
        array (
          'index' => 6,
          'word' => '机智的恋爱生活',
          'query' => '机智的恋爱生活 电视剧',
          'show' => 
          array (
            0 => '中国大陆 | 都市',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/8132e7780917e34755cdd23b3d31d8a8',
          'url' => 'https://www.baidu.com/s?wd=%E6%9C%BA%E6%99%BA%E7%9A%84%E6%81%8B%E7%88%B1%E7%94%9F%E6%B4%BB+%E7%94%B5%E8%A7%86%E5%89%A7&rsv_dl=fyb_homepage_teleplay',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%9C%BA%E6%99%BA%E7%9A%84%E6%81%8B%E7%88%B1%E7%94%9F%E6%B4%BB',
          'hotScore' => '29146',
          'hotChange' => 'up',
        ),
        7 => 
        array (
          'index' => 7,
          'word' => '理想照耀中国',
          'query' => '理想照耀中国 电视剧',
          'show' => 
          array (
            0 => '中国大陆 | 剧情',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/739d5aedf32de1eb412ebbb87a133d72',
          'url' => 'https://www.baidu.com/s?wd=%E7%90%86%E6%83%B3%E7%85%A7%E8%80%80%E4%B8%AD%E5%9B%BD+%E7%94%B5%E8%A7%86%E5%89%A7&rsv_dl=fyb_homepage_teleplay',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E7%90%86%E6%83%B3%E7%85%A7%E8%80%80%E4%B8%AD%E5%9B%BD',
          'hotScore' => '26198',
          'hotChange' => 'down',
        ),
        8 => 
        array (
          'index' => 8,
          'word' => '二龙湖爱情故事2020',
          'query' => '二龙湖爱情故事2020 电视剧',
          'show' => 
          array (
            0 => '中国大陆 | 爱情',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/e99acd8e97a4151d00184dbb41a5c378',
          'url' => 'https://www.baidu.com/s?wd=%E4%BA%8C%E9%BE%99%E6%B9%96%E7%88%B1%E6%83%85%E6%95%85%E4%BA%8B2020+%E7%94%B5%E8%A7%86%E5%89%A7&rsv_dl=fyb_homepage_teleplay',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E4%BA%8C%E9%BE%99%E6%B9%96%E7%88%B1%E6%83%85%E6%95%85%E4%BA%8B2020',
          'hotScore' => '24227',
          'hotChange' => 'same',
        ),
        9 => 
        array (
          'index' => 9,
          'word' => '美好的日子',
          'query' => '美好的日子 电视剧',
          'show' => 
          array (
            0 => '中国大陆 | 全部',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/c9a3c828905981013a71217b29fa11f3',
          'url' => 'https://www.baidu.com/s?wd=%E7%BE%8E%E5%A5%BD%E7%9A%84%E6%97%A5%E5%AD%90+%E7%94%B5%E8%A7%86%E5%89%A7&rsv_dl=fyb_homepage_teleplay',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E7%BE%8E%E5%A5%BD%E7%9A%84%E6%97%A5%E5%AD%90',
          'hotScore' => '19717',
          'hotChange' => 'up',
        ),
      ),
      'more' => 1,
      'moreUrl' => 'https://top.baidu.com/board?tab=teleplay',
    ),
    4 => 
    array (
      'component' => 'textImgListVerticalSmall',
      'text' => '动漫榜',
      'typeName' => 'cartoon',
      'content' => 
      array (
        0 => 
        array (
          'index' => 0,
          'word' => '奥特曼',
          'query' => '奥特曼 动漫',
          'show' => 
          array (
            0 => '日韩 | 热血',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/b24961f1f62825318e6c2d5993efdf20',
          'url' => 'https://www.baidu.com/s?wd=%E5%A5%A5%E7%89%B9%E6%9B%BC+%E5%8A%A8%E6%BC%AB&rsv_dl=fyb_homepage_cartoon',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%A5%A5%E7%89%B9%E6%9B%BC',
          'hotScore' => '71491',
          'hotChange' => 'up',
        ),
        1 => 
        array (
          'index' => 1,
          'word' => '海贼王',
          'query' => '海贼王 动漫',
          'show' => 
          array (
            0 => '日韩 | 搞笑',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/2786c3190b266aab35e8231430557ac3',
          'url' => 'https://www.baidu.com/s?wd=%E6%B5%B7%E8%B4%BC%E7%8E%8B+%E5%8A%A8%E6%BC%AB&rsv_dl=fyb_homepage_cartoon',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%B5%B7%E8%B4%BC%E7%8E%8B',
          'hotScore' => '47542',
          'hotChange' => 'up',
        ),
        2 => 
        array (
          'index' => 2,
          'word' => '火影忍者',
          'query' => '火影忍者 动漫',
          'show' => 
          array (
            0 => '日韩 | 情感',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/5e820832a573f7ea4fbda85f89dab9f1',
          'url' => 'https://www.baidu.com/s?wd=%E7%81%AB%E5%BD%B1%E5%BF%8D%E8%80%85+%E5%8A%A8%E6%BC%AB&rsv_dl=fyb_homepage_cartoon',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E7%81%AB%E5%BD%B1%E5%BF%8D%E8%80%85',
          'hotScore' => '39780',
          'hotChange' => 'up',
        ),
        3 => 
        array (
          'index' => 3,
          'word' => '无敌鹿战队',
          'query' => '无敌鹿战队 动漫',
          'show' => 
          array (
            0 => '中国大陆 | 儿童',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/811db68590a1443648ac8d29b32fec26',
          'url' => 'https://www.baidu.com/s?wd=%E6%97%A0%E6%95%8C%E9%B9%BF%E6%88%98%E9%98%9F+%E5%8A%A8%E6%BC%AB&rsv_dl=fyb_homepage_cartoon',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%97%A0%E6%95%8C%E9%B9%BF%E6%88%98%E9%98%9F',
          'hotScore' => '35491',
          'hotChange' => 'up',
        ),
        4 => 
        array (
          'index' => 4,
          'word' => '熊出没',
          'query' => '熊出没 动漫',
          'show' => 
          array (
            0 => '中国大陆 | 搞笑',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/94dfcd83acd1711855266da59a31ce08',
          'url' => 'https://www.baidu.com/s?wd=%E7%86%8A%E5%87%BA%E6%B2%A1+%E5%8A%A8%E6%BC%AB&rsv_dl=fyb_homepage_cartoon',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E7%86%8A%E5%87%BA%E6%B2%A1',
          'hotScore' => '26238',
          'hotChange' => 'up',
        ),
        5 => 
        array (
          'index' => 5,
          'word' => '小猪佩奇6',
          'query' => '小猪佩奇6 动漫',
          'show' => 
          array (
            0 => '欧美 | 儿童',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/88b73e75dee56ce3f217bfdf7da20cc3',
          'url' => 'https://www.baidu.com/s?wd=%E5%B0%8F%E7%8C%AA%E4%BD%A9%E5%A5%876+%E5%8A%A8%E6%BC%AB&rsv_dl=fyb_homepage_cartoon',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%B0%8F%E7%8C%AA%E4%BD%A9%E5%A5%876',
          'hotScore' => '25429',
          'hotChange' => 'same',
        ),
        6 => 
        array (
          'index' => 6,
          'word' => '小猪佩奇1',
          'query' => '小猪佩奇1 动漫',
          'show' => 
          array (
            0 => '欧美 | 剧情',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/855fba3d1b5a5a664a8b99053b20fb94',
          'url' => 'https://www.baidu.com/s?wd=%E5%B0%8F%E7%8C%AA%E4%BD%A9%E5%A5%871+%E5%8A%A8%E6%BC%AB&rsv_dl=fyb_homepage_cartoon',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%B0%8F%E7%8C%AA%E4%BD%A9%E5%A5%871',
          'hotScore' => '23145',
          'hotChange' => 'up',
        ),
        7 => 
        array (
          'index' => 7,
          'word' => '一拳超人',
          'query' => '一拳超人 动漫',
          'show' => 
          array (
            0 => '日韩 | 热血',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/c420d8b2a05962a2a71cb66033080f09',
          'url' => 'https://www.baidu.com/s?wd=%E4%B8%80%E6%8B%B3%E8%B6%85%E4%BA%BA+%E5%8A%A8%E6%BC%AB&rsv_dl=fyb_homepage_cartoon',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E4%B8%80%E6%8B%B3%E8%B6%85%E4%BA%BA',
          'hotScore' => '19754',
          'hotChange' => 'same',
        ),
        8 => 
        array (
          'index' => 8,
          'word' => '超级小熊布迷',
          'query' => '超级小熊布迷 动漫',
          'show' => 
          array (
            0 => '中国大陆 | 冒险',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/734d90e5a13adec659381a1ef2d11e8a',
          'url' => 'https://www.baidu.com/s?wd=%E8%B6%85%E7%BA%A7%E5%B0%8F%E7%86%8A%E5%B8%83%E8%BF%B7+%E5%8A%A8%E6%BC%AB&rsv_dl=fyb_homepage_cartoon',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E8%B6%85%E7%BA%A7%E5%B0%8F%E7%86%8A%E5%B8%83%E8%BF%B7',
          'hotScore' => '15948',
          'hotChange' => 'down',
        ),
        9 => 
        array (
          'index' => 9,
          'word' => '猫和老鼠',
          'query' => '猫和老鼠 动漫',
          'show' => 
          array (
            0 => '欧美 | 搞笑',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/347a69a5b8c0eb83bfd0ee9f3b0bde4a',
          'url' => 'https://www.baidu.com/s?wd=%E7%8C%AB%E5%92%8C%E8%80%81%E9%BC%A0+%E5%8A%A8%E6%BC%AB&rsv_dl=fyb_homepage_cartoon',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E7%8C%AB%E5%92%8C%E8%80%81%E9%BC%A0',
          'hotScore' => '15408',
          'hotChange' => 'up',
        ),
      ),
      'more' => 1,
      'moreUrl' => 'https://top.baidu.com/board?tab=cartoon',
    ),
    5 => 
    array (
      'component' => 'textImgListVerticalSmall',
      'text' => '综艺榜',
      'typeName' => 'variety',
      'content' => 
      array (
        0 => 
        array (
          'index' => 0,
          'word' => '萌探探探案',
          'query' => '萌探探探案 综艺',
          'show' => 
          array (
            0 => '中国大陆 | 真人秀',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/95884a80f69c1e6680cb7ad7b329399e',
          'url' => 'https://www.baidu.com/s?wd=%E8%90%8C%E6%8E%A2%E6%8E%A2%E6%8E%A2%E6%A1%88+%E7%BB%BC%E8%89%BA&rsv_dl=fyb_homepage_variety',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E8%90%8C%E6%8E%A2%E6%8E%A2%E6%8E%A2%E6%A1%88',
          'hotScore' => '141978',
          'hotChange' => 'down',
        ),
        1 => 
        array (
          'index' => 1,
          'word' => '五十公里桃花坞',
          'query' => '五十公里桃花坞 综艺',
          'show' => 
          array (
            0 => '中国大陆 | 全部',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/e7863cb71aa8455a4acece11c0cec0dd',
          'url' => 'https://www.baidu.com/s?wd=%E4%BA%94%E5%8D%81%E5%85%AC%E9%87%8C%E6%A1%83%E8%8A%B1%E5%9D%9E+%E7%BB%BC%E8%89%BA&rsv_dl=fyb_homepage_variety',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E4%BA%94%E5%8D%81%E5%85%AC%E9%87%8C%E6%A1%83%E8%8A%B1%E5%9D%9E',
          'hotScore' => '76052',
          'hotChange' => 'up',
        ),
        2 => 
        array (
          'index' => 2,
          'word' => '姐妹俱乐部',
          'query' => '姐妹俱乐部 综艺',
          'show' => 
          array (
            0 => '中国大陆 | 真人秀',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/6ef49945a77421e0cd8d4c4408860a93',
          'url' => 'https://www.baidu.com/s?wd=%E5%A7%90%E5%A6%B9%E4%BF%B1%E4%B9%90%E9%83%A8+%E7%BB%BC%E8%89%BA&rsv_dl=fyb_homepage_variety',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%A7%90%E5%A6%B9%E4%BF%B1%E4%B9%90%E9%83%A8',
          'hotScore' => '65647',
          'hotChange' => 'up',
        ),
        3 => 
        array (
          'index' => 3,
          'word' => '向往的生活5',
          'query' => '向往的生活5 综艺',
          'show' => 
          array (
            0 => '中国大陆 | 真人秀',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/0361e4d42988d15d586981d1200b1942',
          'url' => 'https://www.baidu.com/s?wd=%E5%90%91%E5%BE%80%E7%9A%84%E7%94%9F%E6%B4%BB5+%E7%BB%BC%E8%89%BA&rsv_dl=fyb_homepage_variety',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%90%91%E5%BE%80%E7%9A%84%E7%94%9F%E6%B4%BB5',
          'hotScore' => '62703',
          'hotChange' => 'same',
        ),
        4 => 
        array (
          'index' => 4,
          'word' => '快乐大本营',
          'query' => '快乐大本营 综艺',
          'show' => 
          array (
            0 => '中国大陆 | 真人秀',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/d7b205f87c112dcefe411a78fb0b4b85',
          'url' => 'https://www.baidu.com/s?wd=%E5%BF%AB%E4%B9%90%E5%A4%A7%E6%9C%AC%E8%90%A5+%E7%BB%BC%E8%89%BA&rsv_dl=fyb_homepage_variety',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%BF%AB%E4%B9%90%E5%A4%A7%E6%9C%AC%E8%90%A5',
          'hotScore' => '25885',
          'hotChange' => 'up',
        ),
        5 => 
        array (
          'index' => 5,
          'word' => '上班啦妈妈',
          'query' => '上班啦妈妈 综艺',
          'show' => 
          array (
            0 => '中国大陆 | 真人秀',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/d96d39e08c4e9d51d59f73be05f0ad25',
          'url' => 'https://www.baidu.com/s?wd=%E4%B8%8A%E7%8F%AD%E5%95%A6%E5%A6%88%E5%A6%88+%E7%BB%BC%E8%89%BA&rsv_dl=fyb_homepage_variety',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E4%B8%8A%E7%8F%AD%E5%95%A6%E5%A6%88%E5%A6%88',
          'hotScore' => '25323',
          'hotChange' => 'down',
        ),
        6 => 
        array (
          'index' => 6,
          'word' => '奔跑吧5',
          'query' => '奔跑吧5 综艺',
          'show' => 
          array (
            0 => '中国大陆 | 真人秀',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/6953673a50e337f1a4ab6f13c0063a57',
          'url' => 'https://www.baidu.com/s?wd=%E5%A5%94%E8%B7%91%E5%90%A75+%E7%BB%BC%E8%89%BA&rsv_dl=fyb_homepage_variety',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%A5%94%E8%B7%91%E5%90%A75',
          'hotScore' => '21386',
          'hotChange' => 'same',
        ),
        7 => 
        array (
          'index' => 7,
          'word' => '密室大逃脱3',
          'query' => '密室大逃脱3 综艺',
          'show' => 
          array (
            0 => '中国大陆 | 真人秀',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/2c902435575a0c1bb003efb0e44cc27e',
          'url' => 'https://www.baidu.com/s?wd=%E5%AF%86%E5%AE%A4%E5%A4%A7%E9%80%83%E8%84%B13+%E7%BB%BC%E8%89%BA&rsv_dl=fyb_homepage_variety',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%AF%86%E5%AE%A4%E5%A4%A7%E9%80%83%E8%84%B13',
          'hotScore' => '14394',
          'hotChange' => 'up',
        ),
        8 => 
        array (
          'index' => 8,
          'word' => '极限挑战7',
          'query' => '极限挑战7 综艺',
          'show' => 
          array (
            0 => '中国大陆 | 真人秀',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/14c71b80485b96e6e069dcf3ea2b9935',
          'url' => 'https://www.baidu.com/s?wd=%E6%9E%81%E9%99%90%E6%8C%91%E6%88%987+%E7%BB%BC%E8%89%BA&rsv_dl=fyb_homepage_variety',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%9E%81%E9%99%90%E6%8C%91%E6%88%987',
          'hotScore' => '10094',
          'hotChange' => 'same',
        ),
        9 => 
        array (
          'index' => 9,
          'word' => '向往的生活',
          'query' => '向往的生活 综艺',
          'show' => 
          array (
            0 => '中国大陆 | 真人秀',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/49f67b5f265866c39c3226943a553337',
          'url' => 'https://www.baidu.com/s?wd=%E5%90%91%E5%BE%80%E7%9A%84%E7%94%9F%E6%B4%BB+%E7%BB%BC%E8%89%BA&rsv_dl=fyb_homepage_variety',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%90%91%E5%BE%80%E7%9A%84%E7%94%9F%E6%B4%BB',
          'hotScore' => '9330',
          'hotChange' => 'up',
        ),
      ),
      'more' => 1,
      'moreUrl' => 'https://top.baidu.com/board?tab=variety',
    ),
    6 => 
    array (
      'component' => 'textImgListVerticalSmall',
      'text' => '纪录片榜',
      'typeName' => 'documentary',
      'content' => 
      array (
        0 => 
        array (
          'index' => 0,
          'word' => '怪物猎人',
          'query' => '怪物猎人 纪录片',
          'show' => 
          array (
            0 => '欧美',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/47ec3b9e58fa6b78316f09e2bd81d27c',
          'url' => 'https://www.baidu.com/s?wd=%E6%80%AA%E7%89%A9%E7%8C%8E%E4%BA%BA+%E7%BA%AA%E5%BD%95%E7%89%87&rsv_dl=fyb_homepage_documentary',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%80%AA%E7%89%A9%E7%8C%8E%E4%BA%BA',
          'hotScore' => '2128',
          'hotChange' => 'same',
        ),
        1 => 
        array (
          'index' => 1,
          'word' => '大决战',
          'query' => '大决战 纪录片',
          'show' => 
          array (
            0 => '中国大陆',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/6d4d7262d0f3dce57a1275d9728c2580',
          'url' => 'https://www.baidu.com/s?wd=%E5%A4%A7%E5%86%B3%E6%88%98+%E7%BA%AA%E5%BD%95%E7%89%87&rsv_dl=fyb_homepage_documentary',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%A4%A7%E5%86%B3%E6%88%98',
          'hotScore' => '2072',
          'hotChange' => 'down',
        ),
        2 => 
        array (
          'index' => 2,
          'word' => '舌尖上的中国',
          'query' => '舌尖上的中国 纪录片',
          'show' => 
          array (
            0 => '中国大陆',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/a923b5953396f8d25775a1cdcf98e49a',
          'url' => 'https://www.baidu.com/s?wd=%E8%88%8C%E5%B0%96%E4%B8%8A%E7%9A%84%E4%B8%AD%E5%9B%BD+%E7%BA%AA%E5%BD%95%E7%89%87&rsv_dl=fyb_homepage_documentary',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E8%88%8C%E5%B0%96%E4%B8%8A%E7%9A%84%E4%B8%AD%E5%9B%BD',
          'hotScore' => '1706',
          'hotChange' => 'up',
        ),
        3 => 
        array (
          'index' => 3,
          'word' => '雪豹',
          'query' => '雪豹 纪录片',
          'show' => 
          array (
            0 => '中国大陆',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/4db1059c032265cb6efc34f01b9b52ff',
          'url' => 'https://www.baidu.com/s?wd=%E9%9B%AA%E8%B1%B9+%E7%BA%AA%E5%BD%95%E7%89%87&rsv_dl=fyb_homepage_documentary',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E9%9B%AA%E8%B1%B9',
          'hotScore' => '1598',
          'hotChange' => 'same',
        ),
        4 => 
        array (
          'index' => 4,
          'word' => '中国机长',
          'query' => '中国机长 纪录片',
          'show' => 
          array (
            0 => '中国大陆',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/675f5a90a549852f072064d35ed100d6',
          'url' => 'https://www.baidu.com/s?wd=%E4%B8%AD%E5%9B%BD%E6%9C%BA%E9%95%BF+%E7%BA%AA%E5%BD%95%E7%89%87&rsv_dl=fyb_homepage_documentary',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E4%B8%AD%E5%9B%BD%E6%9C%BA%E9%95%BF',
          'hotScore' => '1493',
          'hotChange' => 'up',
        ),
        5 => 
        array (
          'index' => 5,
          'word' => '百家讲坛',
          'query' => '百家讲坛 纪录片',
          'show' => 
          array (
            0 => '中国大陆',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/65408d28460b86df4cdec9a21b1389b9',
          'url' => 'https://www.baidu.com/s?wd=%E7%99%BE%E5%AE%B6%E8%AE%B2%E5%9D%9B+%E7%BA%AA%E5%BD%95%E7%89%87&rsv_dl=fyb_homepage_documentary',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E7%99%BE%E5%AE%B6%E8%AE%B2%E5%9D%9B',
          'hotScore' => '1251',
          'hotChange' => 'up',
        ),
        6 => 
        array (
          'index' => 6,
          'word' => '山河岁月',
          'query' => '山河岁月 纪录片',
          'show' => 
          array (
            0 => '其它',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/08d4988a87376774c6a8819d3db776e0',
          'url' => 'https://www.baidu.com/s?wd=%E5%B1%B1%E6%B2%B3%E5%B2%81%E6%9C%88+%E7%BA%AA%E5%BD%95%E7%89%87&rsv_dl=fyb_homepage_documentary',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%B1%B1%E6%B2%B3%E5%B2%81%E6%9C%88',
          'hotScore' => '1238',
          'hotChange' => 'down',
        ),
        7 => 
        array (
          'index' => 7,
          'word' => '贺子珍',
          'query' => '贺子珍 纪录片',
          'show' => 
          array (
            0 => '中国大陆',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/feef4172075e3481bc3b433bbc12e5f8',
          'url' => 'https://www.baidu.com/s?wd=%E8%B4%BA%E5%AD%90%E7%8F%8D+%E7%BA%AA%E5%BD%95%E7%89%87&rsv_dl=fyb_homepage_documentary',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E8%B4%BA%E5%AD%90%E7%8F%8D',
          'hotScore' => '1230',
          'hotChange' => 'down',
        ),
        8 => 
        array (
          'index' => 8,
          'word' => '航拍中国',
          'query' => '航拍中国 纪录片',
          'show' => 
          array (
            0 => '中国大陆',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/7ac82b032c3f9227569b3a404f892942',
          'url' => 'https://www.baidu.com/s?wd=%E8%88%AA%E6%8B%8D%E4%B8%AD%E5%9B%BD+%E7%BA%AA%E5%BD%95%E7%89%87&rsv_dl=fyb_homepage_documentary',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E8%88%AA%E6%8B%8D%E4%B8%AD%E5%9B%BD',
          'hotScore' => '1228',
          'hotChange' => 'up',
        ),
        9 => 
        array (
          'index' => 9,
          'word' => '天网',
          'query' => '天网 纪录片',
          'show' => 
          array (
            0 => '中国大陆',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/e4ceac69eb41028db0fe45c98e1a87ef',
          'url' => 'https://www.baidu.com/s?wd=%E5%A4%A9%E7%BD%91+%E7%BA%AA%E5%BD%95%E7%89%87&rsv_dl=fyb_homepage_documentary',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%A4%A9%E7%BD%91',
          'hotScore' => '1178',
          'hotChange' => 'down',
        ),
      ),
      'more' => 1,
      'moreUrl' => 'https://top.baidu.com/board?tab=documentary',
    ),
    7 => 
    array (
      'component' => 'textImgListSquareSmall',
      'text' => '明星榜',
      'typeName' => 'star',
      'content' => 
      array (
        0 => 
        array (
          'index' => 0,
          'word' => '张晨光',
          'query' => '张晨光',
          'show' => 
          array (
            0 => '制片、主持人',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/e75faf4593dd9a8b789543fc843ea976',
          'url' => 'https://www.baidu.com/s?wd=%E5%BC%A0%E6%99%A8%E5%85%89&rsv_dl=fyb_homepage_star',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%BC%A0%E6%99%A8%E5%85%89',
          'hotScore' => '133005',
          'hotChange' => 'up',
        ),
        1 => 
        array (
          'index' => 1,
          'word' => '肖战',
          'query' => '肖战',
          'show' => 
          array (
            0 => '歌手、演员',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/226d7b97520b28226719dd54dec7fe60',
          'url' => 'https://www.baidu.com/s?wd=%E8%82%96%E6%88%98&rsv_dl=fyb_homepage_star',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E8%82%96%E6%88%98',
          'hotScore' => '98629',
          'hotChange' => 'up',
        ),
        2 => 
        array (
          'index' => 2,
          'word' => '杨紫',
          'query' => '杨紫',
          'show' => 
          array (
            0 => '歌手、演员',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/491e84b636f617644f1c8ea2a963f9b0',
          'url' => 'https://www.baidu.com/s?wd=%E6%9D%A8%E7%B4%AB&rsv_dl=fyb_homepage_star',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%9D%A8%E7%B4%AB',
          'hotScore' => '95485',
          'hotChange' => 'down',
        ),
        3 => 
        array (
          'index' => 3,
          'word' => '朱一龙',
          'query' => '朱一龙',
          'show' => 
          array (
            0 => '歌手、演员',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/08a6253f8abc6c13a1207559c690ddd7',
          'url' => 'https://www.baidu.com/s?wd=%E6%9C%B1%E4%B8%80%E9%BE%99&rsv_dl=fyb_homepage_star',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%9C%B1%E4%B8%80%E9%BE%99',
          'hotScore' => '82818',
          'hotChange' => 'same',
        ),
        4 => 
        array (
          'index' => 4,
          'word' => '梁静',
          'query' => '梁静',
          'show' => 
          array (
            0 => '主持人、演员',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/c9aa051526429d7293aea733ff9d6be6',
          'url' => 'https://www.baidu.com/s?wd=%E6%A2%81%E9%9D%99&rsv_dl=fyb_homepage_star',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%A2%81%E9%9D%99',
          'hotScore' => '51352',
          'hotChange' => 'up',
        ),
        5 => 
        array (
          'index' => 5,
          'word' => '周冬雨',
          'query' => '周冬雨',
          'show' => 
          array (
            0 => '演员',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/c1ba8de2218afa6aef78769f2edc5ad0',
          'url' => 'https://www.baidu.com/s?wd=%E5%91%A8%E5%86%AC%E9%9B%A8&rsv_dl=fyb_homepage_star',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%91%A8%E5%86%AC%E9%9B%A8',
          'hotScore' => '49207',
          'hotChange' => 'same',
        ),
        6 => 
        array (
          'index' => 6,
          'word' => '黄景瑜',
          'query' => '黄景瑜',
          'show' => 
          array (
            0 => '模特、演员',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/8793f73e70a07176c1d2f1adff9e25f2',
          'url' => 'https://www.baidu.com/s?wd=%E9%BB%84%E6%99%AF%E7%91%9C&rsv_dl=fyb_homepage_star',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E9%BB%84%E6%99%AF%E7%91%9C',
          'hotScore' => '47238',
          'hotChange' => 'down',
        ),
        7 => 
        array (
          'index' => 7,
          'word' => '刘浩存',
          'query' => '刘浩存',
          'show' => 
          array (
            0 => '演员',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/8b84277aaf107758b35b95a7a985a3e4',
          'url' => 'https://www.baidu.com/s?wd=%E5%88%98%E6%B5%A9%E5%AD%98&rsv_dl=fyb_homepage_star',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%88%98%E6%B5%A9%E5%AD%98',
          'hotScore' => '42798',
          'hotChange' => 'up',
        ),
        8 => 
        array (
          'index' => 8,
          'word' => '那英',
          'query' => '那英',
          'show' => 
          array (
            0 => '歌手、演员',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/b1375c534454dc61b22578fb84a3d15b',
          'url' => 'https://www.baidu.com/s?wd=%E9%82%A3%E8%8B%B1&rsv_dl=fyb_homepage_star',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E9%82%A3%E8%8B%B1',
          'hotScore' => '36664',
          'hotChange' => 'up',
        ),
        9 => 
        array (
          'index' => 9,
          'word' => '张子枫',
          'query' => '张子枫',
          'show' => 
          array (
            0 => '演员',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/586afa232e2c3b55a78c871cd24c39c6',
          'url' => 'https://www.baidu.com/s?wd=%E5%BC%A0%E5%AD%90%E6%9E%AB&rsv_dl=fyb_homepage_star',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%BC%A0%E5%AD%90%E6%9E%AB',
          'hotScore' => '35053',
          'hotChange' => 'up',
        ),
      ),
      'more' => 1,
      'moreUrl' => 'https://top.baidu.com/board?tab=star',
    ),
    8 => 
    array (
      'component' => 'textImgListSquareSmall',
      'text' => '汽车榜',
      'typeName' => 'car',
      'content' => 
      array (
        0 => 
        array (
          'index' => 0,
          'word' => '奔腾B70',
          'query' => '奔腾B70 汽车',
          'show' => 
          array (
            0 => '9.9-13.9万',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/152e239c4bb5f664a6ca2039a94f7f74',
          'url' => 'https://www.baidu.com/s?wd=%E5%A5%94%E8%85%BEB70+%E6%B1%BD%E8%BD%A6&rsv_dl=fyb_homepage_car',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%A5%94%E8%85%BEB70',
          'hotScore' => '22149',
          'hotChange' => 'up',
          'price' => '9.9-13.9万',
          'imgSquare' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/b5598da0e1b90fd62682d6541e134b33',
        ),
        1 => 
        array (
          'index' => 1,
          'word' => '坦克300',
          'query' => '坦克300 汽车',
          'show' => 
          array (
            0 => '17-22万',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/b73376fad1af1791710cefd4b122f464',
          'url' => 'https://www.baidu.com/s?wd=%E5%9D%A6%E5%85%8B300+%E6%B1%BD%E8%BD%A6&rsv_dl=fyb_homepage_car',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%9D%A6%E5%85%8B300',
          'hotScore' => '22010',
          'hotChange' => 'same',
          'price' => '17-22万',
          'imgSquare' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/7da1ab5476ae002d84924f5c885ad597',
        ),
        2 => 
        array (
          'index' => 2,
          'word' => '伊兰特',
          'query' => '伊兰特 汽车',
          'show' => 
          array (
            0 => '9.9-14.1万',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/78117f0ac2ae72ff891e3ce17c099cef',
          'url' => 'https://www.baidu.com/s?wd=%E4%BC%8A%E5%85%B0%E7%89%B9+%E6%B1%BD%E8%BD%A6&rsv_dl=fyb_homepage_car',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E4%BC%8A%E5%85%B0%E7%89%B9',
          'hotScore' => '15839',
          'hotChange' => 'down',
          'price' => '9.9-14.1万',
          'imgSquare' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/f8eb181f63d08e02d38a0d483b8c6fcd',
        ),
        3 => 
        array (
          'index' => 3,
          'word' => '宝马5系',
          'query' => '宝马5系 汽车',
          'show' => 
          array (
            0 => '42.1-54.9万',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/918577b1624f384afc04a72a509a16e1',
          'url' => 'https://www.baidu.com/s?wd=%E5%AE%9D%E9%A9%AC5%E7%B3%BB+%E6%B1%BD%E8%BD%A6&rsv_dl=fyb_homepage_car',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%AE%9D%E9%A9%AC5%E7%B3%BB',
          'hotScore' => '10584',
          'hotChange' => 'up',
          'price' => '42.1-54.9万',
          'imgSquare' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/3ddfac3bc2446ad673963a06596d2ab9',
        ),
        4 => 
        array (
          'index' => 4,
          'word' => '雅阁',
          'query' => '雅阁 汽车',
          'show' => 
          array (
            0 => '17.9-25.9万',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/781ef0c42da0e56eca9071a4022b996c',
          'url' => 'https://www.baidu.com/s?wd=%E9%9B%85%E9%98%81+%E6%B1%BD%E8%BD%A6&rsv_dl=fyb_homepage_car',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E9%9B%85%E9%98%81',
          'hotScore' => '10220',
          'hotChange' => 'same',
          'price' => '17.9-25.9万',
          'imgSquare' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/781ef0c42da0e56eca9071a4022b996c',
        ),
        5 => 
        array (
          'index' => 5,
          'word' => '卡罗拉',
          'query' => '卡罗拉 汽车',
          'show' => 
          array (
            0 => '10.9-15.9万',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/eaa8a3e11ffd6e9ecabc101d2000650c',
          'url' => 'https://www.baidu.com/s?wd=%E5%8D%A1%E7%BD%97%E6%8B%89+%E6%B1%BD%E8%BD%A6&rsv_dl=fyb_homepage_car',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%8D%A1%E7%BD%97%E6%8B%89',
          'hotScore' => '9988',
          'hotChange' => 'same',
          'price' => '10.9-15.9万',
          'imgSquare' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/eaa8a3e11ffd6e9ecabc101d2000650c',
        ),
        6 => 
        array (
          'index' => 6,
          'word' => '哈弗初恋',
          'query' => '哈弗初恋 汽车',
          'show' => 
          array (
            0 => '7.8-11.2万',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/53ae2fbf13f4163caadfda8df5e7a756',
          'url' => 'https://www.baidu.com/s?wd=%E5%93%88%E5%BC%97%E5%88%9D%E6%81%8B+%E6%B1%BD%E8%BD%A6&rsv_dl=fyb_homepage_car',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%93%88%E5%BC%97%E5%88%9D%E6%81%8B',
          'hotScore' => '9419',
          'hotChange' => 'down',
          'price' => '7.8-11.2万',
          'imgSquare' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/1e882b0e49629ff622cf6f23f16e14f4',
        ),
        7 => 
        array (
          'index' => 7,
          'word' => '宝马3系',
          'query' => '宝马3系 汽车',
          'show' => 
          array (
            0 => '29.3-40.9万',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/d0787b06f41714b1f45e100bd74ec6a3',
          'url' => 'https://www.baidu.com/s?wd=%E5%AE%9D%E9%A9%AC3%E7%B3%BB+%E6%B1%BD%E8%BD%A6&rsv_dl=fyb_homepage_car',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%AE%9D%E9%A9%AC3%E7%B3%BB',
          'hotScore' => '9412',
          'hotChange' => 'same',
          'price' => '29.3-40.9万',
          'imgSquare' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/f8f0537f60b5e82daf9285cd86ea9ff0',
        ),
        8 => 
        array (
          'index' => 8,
          'word' => '汉兰达',
          'query' => '汉兰达 汽车',
          'show' => 
          array (
            0 => '23.9-32.5万',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/29fcc8f9cec9ea459ac32327cd566242',
          'url' => 'https://www.baidu.com/s?wd=%E6%B1%89%E5%85%B0%E8%BE%BE+%E6%B1%BD%E8%BD%A6&rsv_dl=fyb_homepage_car',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%B1%89%E5%85%B0%E8%BE%BE',
          'hotScore' => '9187',
          'hotChange' => 'up',
          'price' => '23.9-32.5万',
          'imgSquare' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/2a6d0487b9c068d1c7a4d4340b02a835',
        ),
        9 => 
        array (
          'index' => 9,
          'word' => '思域',
          'query' => '思域 汽车',
          'show' => 
          array (
            0 => '11.9-16.9万',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/ad4ca840b01dd05e2578ad5b3e2ab39e',
          'url' => 'https://www.baidu.com/s?wd=%E6%80%9D%E5%9F%9F+%E6%B1%BD%E8%BD%A6&rsv_dl=fyb_homepage_car',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%80%9D%E5%9F%9F',
          'hotScore' => '8958',
          'hotChange' => 'up',
          'price' => '11.9-16.9万',
          'imgSquare' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/ad4ca840b01dd05e2578ad5b3e2ab39e',
        ),
      ),
      'more' => 1,
      'moreUrl' => 'https://top.baidu.com/board?tab=car',
    ),
    9 => 
    array (
      'component' => 'textImgListSquareSmall',
      'text' => '游戏榜',
      'typeName' => 'game',
      'content' => 
      array (
        0 => 
        array (
          'index' => 0,
          'word' => '王者荣耀',
          'query' => '王者荣耀 游戏',
          'show' => 
          array (
            0 => '手机游戏',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/0752a1fdca7ef4113f433869372dd926',
          'url' => 'https://www.baidu.com/s?wd=%E7%8E%8B%E8%80%85%E8%8D%A3%E8%80%80+%E6%B8%B8%E6%88%8F&rsv_dl=fyb_homepage_game',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E7%8E%8B%E8%80%85%E8%8D%A3%E8%80%80',
          'hotScore' => '191671',
          'hotChange' => 'up',
        ),
        1 => 
        array (
          'index' => 1,
          'word' => '原神',
          'query' => '原神 游戏',
          'show' => 
          array (
            0 => '单机游戏',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/f23d84f97d93ea8b19b6e701b0e82789',
          'url' => 'https://www.baidu.com/s?wd=%E5%8E%9F%E7%A5%9E+%E6%B8%B8%E6%88%8F&rsv_dl=fyb_homepage_game',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%8E%9F%E7%A5%9E',
          'hotScore' => '108640',
          'hotChange' => 'up',
        ),
        2 => 
        array (
          'index' => 2,
          'word' => '我的世界',
          'query' => '我的世界 游戏',
          'show' => 
          array (
            0 => '手机游戏',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/876a6fb5671e6451817f1ec8af9f590e',
          'url' => 'https://www.baidu.com/s?wd=%E6%88%91%E7%9A%84%E4%B8%96%E7%95%8C+%E6%B8%B8%E6%88%8F&rsv_dl=fyb_homepage_game',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%88%91%E7%9A%84%E4%B8%96%E7%95%8C',
          'hotScore' => '101115',
          'hotChange' => 'up',
        ),
        3 => 
        array (
          'index' => 3,
          'word' => '迷你世界',
          'query' => '迷你世界 游戏',
          'show' => 
          array (
            0 => '手机游戏',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/3ba1a3cec85902c4e27ea6209f1de357',
          'url' => 'https://www.baidu.com/s?wd=%E8%BF%B7%E4%BD%A0%E4%B8%96%E7%95%8C+%E6%B8%B8%E6%88%8F&rsv_dl=fyb_homepage_game',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E8%BF%B7%E4%BD%A0%E4%B8%96%E7%95%8C',
          'hotScore' => '85316',
          'hotChange' => 'up',
        ),
        4 => 
        array (
          'index' => 4,
          'word' => '香肠派对',
          'query' => '香肠派对 游戏',
          'show' => 
          array (
            0 => '手机游戏',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/4873cf9e40bae6eaab98938d6da37c3c',
          'url' => 'https://www.baidu.com/s?wd=%E9%A6%99%E8%82%A0%E6%B4%BE%E5%AF%B9+%E6%B8%B8%E6%88%8F&rsv_dl=fyb_homepage_game',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E9%A6%99%E8%82%A0%E6%B4%BE%E5%AF%B9',
          'hotScore' => '84679',
          'hotChange' => 'up',
        ),
        5 => 
        array (
          'index' => 5,
          'word' => '摩尔庄园',
          'query' => '摩尔庄园 游戏',
          'show' => 
          array (
            0 => '手机游戏',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/1ae34c38a6649b708e81f6ab5c393508',
          'url' => 'https://www.baidu.com/s?wd=%E6%91%A9%E5%B0%94%E5%BA%84%E5%9B%AD+%E6%B8%B8%E6%88%8F&rsv_dl=fyb_homepage_game',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%91%A9%E5%B0%94%E5%BA%84%E5%9B%AD',
          'hotScore' => '82665',
          'hotChange' => 'down',
        ),
        6 => 
        array (
          'index' => 6,
          'word' => '和平精英',
          'query' => '和平精英 游戏',
          'show' => 
          array (
            0 => '手机游戏',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/c09c3aca9cb3da5ae223d86fe08ea3cd',
          'url' => 'https://www.baidu.com/s?wd=%E5%92%8C%E5%B9%B3%E7%B2%BE%E8%8B%B1+%E6%B8%B8%E6%88%8F&rsv_dl=fyb_homepage_game',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%92%8C%E5%B9%B3%E7%B2%BE%E8%8B%B1',
          'hotScore' => '69582',
          'hotChange' => 'same',
        ),
        7 => 
        array (
          'index' => 7,
          'word' => '光遇',
          'query' => '光遇 游戏',
          'show' => 
          array (
            0 => '手机游戏',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/8dce0f78d5451529d0b549b18806f064',
          'url' => 'https://www.baidu.com/s?wd=%E5%85%89%E9%81%87+%E6%B8%B8%E6%88%8F&rsv_dl=fyb_homepage_game',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E5%85%89%E9%81%87',
          'hotScore' => '45486',
          'hotChange' => 'up',
        ),
        8 => 
        array (
          'index' => 8,
          'word' => '植物大战僵尸',
          'query' => '植物大战僵尸 游戏',
          'show' => 
          array (
            0 => '单机游戏',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/57d3e6c81efb5a455c4c85a87e5c6708',
          'url' => 'https://www.baidu.com/s?wd=%E6%A4%8D%E7%89%A9%E5%A4%A7%E6%88%98%E5%83%B5%E5%B0%B8+%E6%B8%B8%E6%88%8F&rsv_dl=fyb_homepage_game',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%A4%8D%E7%89%A9%E5%A4%A7%E6%88%98%E5%83%B5%E5%B0%B8',
          'hotScore' => '43238',
          'hotChange' => 'up',
        ),
        9 => 
        array (
          'index' => 9,
          'word' => '永劫无间',
          'query' => '永劫无间 游戏',
          'show' => 
          array (
            0 => '单机游戏',
          ),
          'img' => 'https://fyb-1.cdn.bcebos.com/fyb-1/20210620/7acae251aa9d6da06b0db151382039aa',
          'url' => 'https://www.baidu.com/s?wd=%E6%B0%B8%E5%8A%AB%E6%97%A0%E9%97%B4+%E6%B8%B8%E6%88%8F&rsv_dl=fyb_homepage_game',
          'rawUrl' => 'https://www.baidu.com/s?wd=%E6%B0%B8%E5%8A%AB%E6%97%A0%E9%97%B4',
          'hotScore' => '42993',
          'hotChange' => 'down',
        ),
      ),
      'more' => 1,
      'moreUrl' => 'https://top.baidu.com/board?tab=game',
    ),
  ),
);