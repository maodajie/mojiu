<?php
return array (
  'time' => 1623646976,
  'data' => 
  array (
    0 => 
    array (
      'name' => '电影',
      'list' => 
      array (
        0 => 
        array (
          'keyword' => '叛逆者',
          'searches' => 24395,
          'changeRate' => -3,
          'isNew' => '',
          'trend' => 'fall',
          'gentime' => '2021-06-13 11:21:06',
          'links' => 
          array (
            4 => 
            array (
              0 => 'http://baike.baidu.com/subview/110098/110098.htm',
              1 => '简介',
            ),
            5 => 
            array (
              0 => 'http://news.baidu.com/ns?tn=news&from=news&cl=2&rn=20&ct=1&word=%C5%D1%C4%E6%D5%DF',
              1 => '新闻',
            ),
            6 => 
            array (
              0 => 'http://index.baidu.com/?tpl=trend&word=%C5%D1%C4%E6%D5%DF',
              1 => '指数',
            ),
          ),
        ),
        1 => 
        array (
          'keyword' => '洛基',
          'searches' => 14014,
          'changeRate' => -18,
          'isNew' => '',
          'trend' => 'fall',
          'links' => 
          array (
            4 => 
            array (
              0 => 'http://baike.baidu.com/subview/22250/8978933.htm',
              1 => '简介',
            ),
            5 => 
            array (
              0 => 'http://news.baidu.com/ns?tn=news&from=news&cl=2&rn=20&ct=1&word=%C2%E5%BB%F9',
              1 => '新闻',
            ),
            6 => 
            array (
              0 => 'http://index.baidu.com/?tpl=trend&word=%C2%E5%BB%F9',
              1 => '指数',
            ),
          ),
        ),
        2 => 
        array (
          'keyword' => '追虎擒龙',
          'searches' => 6940,
          'changeRate' => 271,
          'isNew' => '',
          'trend' => 'rise',
          'links' => 
          array (
            4 => 
            array (
              0 => 'http://baike.baidu.com/subview/1304739/1304739.htm',
              1 => '简介',
            ),
            5 => 
            array (
              0 => 'http://news.baidu.com/ns?tn=news&from=news&cl=2&rn=20&ct=1&word=%D7%B7%BB%A2%C7%DC%C1%FA',
              1 => '新闻',
            ),
            6 => 
            array (
              0 => 'http://index.baidu.com/?tpl=trend&word=%D7%B7%BB%A2%C7%DC%C1%FA',
              1 => '指数',
            ),
          ),
        ),
        3 => 
        array (
          'keyword' => '顶楼',
          'searches' => 5345,
          'changeRate' => 71,
          'isNew' => '',
          'trend' => 'rise',
          'links' => 
          array (
            4 => 
            array (
              0 => 'http://baike.baidu.com/subview/5045653/5051046.htm',
              1 => '简介',
            ),
            5 => 
            array (
              0 => 'http://news.baidu.com/ns?tn=news&from=news&cl=2&rn=20&ct=1&word=%B6%A5%C2%A5',
              1 => '新闻',
            ),
            6 => 
            array (
              0 => 'http://index.baidu.com/?tpl=trend&word=%B6%A5%C2%A5',
              1 => '指数',
            ),
          ),
        ),
        4 => 
        array (
          'keyword' => '秘密访客',
          'searches' => 5263,
          'changeRate' => -15,
          'isNew' => '',
          'trend' => 'fall',
          'links' => 
          array (
            4 => 
            array (
              0 => 'http://baike.baidu.com/item/%E7%A7%98%E5%AF%86%E8%AE%BF%E5%AE%A2',
              1 => '简介',
            ),
            5 => 
            array (
              0 => 'http://news.baidu.com/ns?tn=news&from=news&cl=2&rn=20&ct=1&word=%C3%D8%C3%DC%B7%C3%BF%CD',
              1 => '新闻',
            ),
            6 => 
            array (
              0 => 'http://index.baidu.com/?tpl=trend&word=%C3%D8%C3%DC%B7%C3%BF%CD',
              1 => '指数',
            ),
          ),
        ),
        5 => 
        array (
          'keyword' => '咸鱼',
          'searches' => 2328,
          'changeRate' => -27,
          'isNew' => '',
          'trend' => 'fall',
          'links' => 
          array (
            4 => 
            array (
              0 => 'http://baike.baidu.com/subview/252538/5665972.htm',
              1 => '简介',
            ),
            5 => 
            array (
              0 => 'http://news.baidu.com/ns?tn=news&from=news&cl=2&rn=20&ct=1&word=%CF%CC%D3%E3',
              1 => '新闻',
            ),
            6 => 
            array (
              0 => 'http://index.baidu.com/?tpl=trend&word=%CF%CC%D3%E3',
              1 => '指数',
            ),
          ),
        ),
        6 => 
        array (
          'keyword' => '天堂电影院',
          'searches' => 2293,
          'changeRate' => -12,
          'isNew' => '',
          'trend' => 'fall',
          'links' => 
          array (
            4 => 
            array (
              0 => 'http://baike.baidu.com/view/42080.htm',
              1 => '简介',
            ),
            5 => 
            array (
              0 => 'http://news.baidu.com/ns?tn=news&from=news&cl=2&rn=20&ct=1&word=%CC%EC%CC%C3%B5%E7%D3%B0%D4%BA',
              1 => '新闻',
            ),
            6 => 
            array (
              0 => 'http://index.baidu.com/?tpl=trend&word=%CC%EC%CC%C3%B5%E7%D3%B0%D4%BA',
              1 => '指数',
            ),
          ),
        ),
        7 => 
        array (
          'keyword' => '控制',
          'searches' => 2161,
          'changeRate' => -58,
          'isNew' => '',
          'trend' => 'fall',
          'links' => 
          array (
            4 => 
            array (
              0 => 'http://baike.baidu.com/subview/57913/11192440.htm',
              1 => '简介',
            ),
            5 => 
            array (
              0 => 'http://news.baidu.com/ns?tn=news&from=news&cl=2&rn=20&ct=1&word=%BF%D8%D6%C6',
              1 => '新闻',
            ),
            6 => 
            array (
              0 => 'http://index.baidu.com/?tpl=trend&word=%BF%D8%D6%C6',
              1 => '指数',
            ),
          ),
        ),
        8 => 
        array (
          'keyword' => '三体',
          'searches' => 2050,
          'changeRate' => 1,
          'isNew' => '',
          'trend' => 'rise',
          'links' => 
          array (
            4 => 
            array (
              0 => 'http://baike.baidu.com/subview/449240/15853722.htm',
              1 => '简介',
            ),
            5 => 
            array (
              0 => 'http://news.baidu.com/ns?tn=news&from=news&cl=2&rn=20&ct=1&word=%C8%FD%CC%E5',
              1 => '新闻',
            ),
            6 => 
            array (
              0 => 'http://index.baidu.com/?tpl=trend&word=%C8%FD%CC%E5',
              1 => '指数',
            ),
          ),
        ),
        9 => 
        array (
          'keyword' => '钢铁侠3',
          'searches' => 1922,
          'changeRate' => 2,
          'isNew' => '',
          'trend' => 'rise',
          'links' => 
          array (
            4 => 
            array (
              0 => 'http://baike.baidu.com/view/3256327.htm',
              1 => '简介',
            ),
            5 => 
            array (
              0 => 'http://news.baidu.com/ns?tn=news&from=news&cl=2&rn=20&ct=1&word=%B8%D6%CC%FA%CF%C03',
              1 => '新闻',
            ),
            6 => 
            array (
              0 => 'http://index.baidu.com/?tpl=trend&word=%B8%D6%CC%FA%CF%C03',
              1 => '指数',
            ),
          ),
        ),
      ),
    ),
  ),
  'keyword' => 
  array (
    0 => '叛逆者',
    1 => '洛基',
    2 => '追虎擒龙',
    3 => '顶楼',
    4 => '秘密访客',
    5 => '咸鱼',
    6 => '天堂电影院',
    7 => '控制',
    8 => '三体',
    9 => '钢铁侠3',
  ),
  'searches' => 
  array (
    0 => 24395,
    1 => 14014,
    2 => 6940,
    3 => 5345,
    4 => 5263,
    5 => 2328,
    6 => 2293,
    7 => 2161,
    8 => 2050,
    9 => 1922,
  ),
  'trend' => 
  array (
    0 => 'fall',
    1 => 'fall',
    2 => 'rise',
    3 => 'rise',
    4 => 'fall',
    5 => 'fall',
    6 => 'fall',
    7 => 'fall',
    8 => 'rise',
    9 => 'rise',
  ),
);